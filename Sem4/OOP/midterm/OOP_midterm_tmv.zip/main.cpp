#include "AdvisorBot.h"

int main()
{
    // Instantiating a class
    AdvisorBot applicationObj;

    // Initialize application
    applicationObj.init();

    return 0;
}